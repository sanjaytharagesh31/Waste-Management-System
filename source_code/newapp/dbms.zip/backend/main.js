var express = require("express");
var bodyParser = require("body-parser");
var mysql = require("mysql");
var fs = require('fs');

var app = express()
app.use(bodyParser.urlencoded({
  extended: false
}));

var connection = mysql.createConnection({
  host: 'localhost',
  port: '3306',
  user: 'admin',
  password: 'dbms_project',
  database: 'nfdb'
});


app.get('/', function (req, res) {
  //res.sendFile('__dirname','first.html');
  res.sendFile('D:\\cloud\\dbms_app\\newapp\\client_login\\index.html');
});

app.get('/user', function (req, res) {
  //res.sendFile('__dirname','first.html');
  res.sendFile('D:\\cloud\\dbms_app\\newapp\\client_login\\index.html');
});

app.get('/admin', function (req, res) {
  //res.sendFile('__dirname','first.html');
  res.sendFile('D:\\cloud\\dbms_app\\newapp\\admin_login\\index.html');
});

app.get('/register_user', function (req, res) {
  //res.sendFile('__dirname','first.html');
  res.sendFile('D:\\cloud\\dbms_app\\newapp\\forms\\user_reg.html');
});

app.post('/ulogin', function (req, res) {
  let user_name = req.body.username;
  let user_password = req.body.password;
  console.log(user_name + " " + user_password);
  connection.query('SELECT u_password FROM client WHERE user_id="' + user_name + '";', function (err, result, fields) {
    if (err) throw err;
    console.log("data retrieved");
    let r = result[0].u_password;
    console.log(r);
    if (user_password != r)
      res.send('Authentication failed');
    else
      res.sendFile('D:\\cloud\\dbms_app\\newapp\\dashboard\\user_dash.html');
  });
});

app.post('/alogin', function (req, res) {
  let admin_name = req.body.adminname;
  let admin_password = req.body.password;

  console.log(admin_name + " " + admin_password);
  connection.query('SELECT a_password FROM admin WHERE admin_id="' + admin_name + '";', function (err, result, fields) {
    if (err) throw err;
    console.log("data retrieved");
    let r = result[0].a_password;
    console.log(r);
    if (admin_password != r)
      res.send('Authentication failed');
    else
      res.sendFile('D:\\cloud\\dbms_app\\newapp\\dashboard\\admin_dash.html');
  });
});

app.get('/ulogin/complaint', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\forms\\complaint_dash.html");
});

app.get('/ulogin/waste_produce', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\forms\\waste_produce_dash.html");
});

app.get('/ulogin/user_dash', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\dashboard\\user_dash.html");
});

app.get('/alogin/admin_dash', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\dashboard\\admin_dash.html");
});

app.get('/alogin/area_details', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\dashboard\\area_details_dash.html");
});

app.get('/alogin/area_details/add_area', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\forms\\add_area_dash.html");
});

app.get('/alogin/area_details/update_area', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\forms\\update_area_dash.html");
});

app.get('/alogin/area_details/delete_area', function (req, res) {
  res.sendFile("D:\\cloud\\dbms_app\\newapp\\forms\\delete_area_dash.html");
});

var server = app.listen(3000, function () {
  console.log('Node server is running on port 3000');
});